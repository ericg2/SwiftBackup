﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Security.Authentication.ExtendedProtection;
using System.Text;
using System.Threading.Tasks;

namespace SwiftUtils
{
    public class SwiftServer
    {
        #region Client Implementation
        private class ServerClient : IServerClient
        {
            public string ID { set; get; }

            public DateTime ConnectTime { set; get; }

            public DateTime KeepAlive { set; get; }

            public TcpClient Socket { get; }

            public SwiftServer AssociatedServer { get; }

            public bool IsHandshake { set; get; }

            public IPAddress? Address
            {
                get
                {
                    if (!IsConnected)
                        return null;

                    EndPoint? ep = Socket.Client.RemoteEndPoint;
                    if (ep == null)
                        return null;

                    return (ep as IPEndPoint)!.Address;
                }
            }

            public NetworkStream Stream
            {
                get { return Socket.GetStream(); }
            }

            public bool IsConnected
            {
                get { return Socket.Connected; }
            }

            public bool Kick()
            {
                // Attempt to kick the client off the server.
                return AssociatedServer.Kick(this);
            }

            public bool SendMessage(string message)
            {
                return SendMessage(SocketUtil.ENCODING.GetBytes(message));
            }

            public bool SendMessage(byte[] message)
            {
                if (!IsConnected)
                    return false;

                // Generate the packet using the encryption key.
                byte[]? output = SocketUtil.GeneratePacket(message, AssociatedServer._PasswordHash);
                if (output == null)
                    return false;

                try
                {
                    Stream.Write(output);
                    Stream.Flush();
                    return true;
                }
                catch (Exception)
                {
                    Kick(); // the socket is disconnected. kick it from the list.
                    return false;
                }
            }

            public ServerClient(SwiftServer server, TcpClient socket)
            {
                AssociatedServer = server;
                ConnectTime = DateTime.Now;
                Socket = socket;
                KeepAlive = DateTime.Now.AddMinutes(1);
                IsHandshake = false;

                // Attempt to generate an ID whcich is UNIQUE.
                for (int i=0; i<100; i++)
                {
                    string id = SocketUtil.GenerateRandomString(4);
                    bool bad = false;
                    foreach (ServerClient client in AssociatedServer._Clients)
                    {
                        if (client.ID == id)
                        {
                            bad = true;
                            break;
                        }
                    }
                    if (!bad)
                    {
                        ID = id;
                        break;
                    }
                }
                if (string.IsNullOrEmpty(ID))
                    throw new SystemException();
            }
        }

        public class ServerClientEventArgs : EventArgs
        {
            public SwiftServer Server { private set; get; }
            public IServerClient Client { private set; get; }
            public byte[] Message { private set; get; }

            public ServerClientEventArgs(SwiftServer server, IServerClient client, byte[] message)
            {
                Server = server;
                Client = client;
                Message = message;
            }
        }
        #endregion

        private byte[]? _PasswordHash;
        private Thread? _AcceptThread;
        private TcpListener? _Listener;
        private SimpleLogger _Logger;
        private List<ServerClient> _Clients;

        private object _ClientLock = new();

        public event EventHandler<ServerClientEventArgs>? ClientConnected;
        public event EventHandler<ServerClientEventArgs>? ClientDisconnected;
        public event EventHandler<ServerClientEventArgs>? MessageReceived;
   
        public uint MaxClients { set; get; }
        public ushort Port { set; get; }
        public bool IsRunning { private set; get; }
        public DateTime? StartTime { private set; get; }

        public IEnumerable<IServerClient> Clients
        {
            get
            {
                return [.. _Clients ];
            }
        }

        public string Password
        {
            set
            {
                _PasswordHash = string.IsNullOrEmpty(value) ? null : SocketUtil.ComputeSHA256(SocketUtil.ENCODING.GetBytes(value));
            }
        }

        public TimeSpan Uptime
        {
            get
            {
                if (StartTime == null)
                    return TimeSpan.FromSeconds(0); // never started
                return (TimeSpan)(DateTime.Now - StartTime);
            }
        }

        public SwiftServer(ushort port=8080, bool logEnabled=false)
        {
            _Logger = new SimpleLogger();
            _Clients = new List<ServerClient>();
            Port = port;
            if (logEnabled)
                _Logger.Start();
        }

        public static (T1?, T2?) WhenAny<T1, T2>(IEnumerable<Task<T1>> taskList, Task<T2>? singleTask) where T2: class
        {
            var taskArray = new List<Task>();
            taskArray.AddRange(taskList);
            if (singleTask != null)
                taskArray.Add(singleTask);

            Task.WaitAny(taskArray.ToArray());

            if (singleTask != null && singleTask.IsCompleted)
            {
                return (default, singleTask.Result);
            }

            foreach (var task in taskList)
            {
                if (task.IsCompleted)
                {
                    return (task.Result, null);
                }
            }
            return (default, null);
        }



        public void HandleClients()
        {
            // A set to keep track of running tasks.
            HashSet<Task> runningTasks = new HashSet<Task>();

            // Add receiving tasks for existing clients
            for (int i = 0; i < _Clients.Count; i++)
            {
                var receiveTask = SocketUtil.ReceivePacketBytesAsync(_Clients[i].Stream, _PasswordHash);
                runningTasks.Add(receiveTask);
            }

            // Add listener task if the server can accept more clients
            if (_Listener != null && (MaxClients == 0 || _Clients.Count < MaxClients))
            {
                var acceptTask = _Listener.AcceptTcpClientAsync();
                runningTasks.Add(acceptTask);
            }

            while (IsRunning)
            {
                // Wait for any task to complete
                Task completedTask = Task.WhenAny(runningTasks).Result;

                // Handle the completed task
                if (completedTask is Task<byte[]> rT)
                {
                    int clientIndex = Array.IndexOf(runningTasks.ToArray(), rT);
                    var client = _Clients[clientIndex];

                    if (rT.IsCompletedSuccessfully && rT.Result != null)
                    {
                        HandleReceivedData(client, rT.Result);
                    }
                    else
                    {
                        HandleClientKeepAlive(client);
                    }

                }
                else if (completedTask is Task<TcpClient> acceptTask && acceptTask.IsCompletedSuccessfully)
                {
                    TcpClient newClient = acceptTask.Result;
                    if (newClient.Connected)
                    {
                        ServerClient serverClient = new ServerClient(this, newClient);
                        lock (_ClientLock)
                        {
                            _Clients.Add(serverClient);
                        }
                        ClientConnected?.Invoke(this, new ServerClientEventArgs(this, serverClient, SocketUtil.ENCODING.GetBytes("Connected")));
                    }
                }

                // Remove the completed task from the set
                runningTasks.Remove(completedTask);
            }
        }

        private void HandleReceivedData(ServerClient client, byte[] data)
        {
            string message = SocketUtil.ENCODING.GetString(data);

            switch (message)
            {
                case "SERVACK":
                    client.IsHandshake = true;
                    ClientConnected?.Invoke(this, new ServerClientEventArgs(this, client, SocketUtil.ENCODING.GetBytes("Connected")));
                    break;

                case "SERVDISCONNECT":
                    Kick(client);
                    break;

                case "SERVKEEPALIVE":
                    client.KeepAlive = DateTime.Now.AddMinutes(1);
                    break;

                default:
                    client.KeepAlive = DateTime.Now.AddMinutes(1);
                    MessageReceived?.Invoke(this, new ServerClientEventArgs(this, client, data));
                    break;
            }
        }

        private void HandleClientKeepAlive(ServerClient client)
        {
            if (DateTime.Now >= client.KeepAlive)
            {
                Kick(client);
            }
        }

        public bool Kick(IServerClient client)
        {
            // Attempt to find the specified client.
            lock (_ClientLock)
            {
                for (int i = 0; i < _Clients.Count; i++)
                {
                    ServerClient kvp = _Clients.ElementAt(i);
                    if (kvp.ID == client.ID)
                    {
                        // Send a disconnect packet to the client.
                        kvp.Socket.Close();
                        kvp.Socket.Dispose();
                        bool ret = _Clients.Remove(kvp);
                        if (ret)
                            _Logger.Info($"Successfully kicked client {kvp}");
                        else
                            _Logger.Error($"Failed to kick client {kvp}");
                        return ret;
                    }
                }
            }
            return false;
        }

        public bool Start()
        {
            if (IsRunning)
            {
                _Logger.Error("The 'start' method has been called while the server was running!");
                return false;
            }

            _Listener = new TcpListener(IPAddress.Any, Port);
            _Listener.Start();
            IsRunning = true;
            _AcceptThread = new Thread(new ThreadStart(HandleClients));
            _AcceptThread.Start();
            StartTime = DateTime.Now;

            return true;
        }
    }
}
